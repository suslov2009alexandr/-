import smtplib


def send_message(recipient, message):
    msc_mail_server = 'smtp.mail.ru'
    msc_from_address = 'live_queue@mail.ru'
    msc_login_user = 'live_queue'
    msc_login_pass = 'rTh09XrpeFhtqUjqneF1'  # 'LiveQueue'
    smtp_link = smtplib.SMTP_SSL(msc_mail_server)
    smtp_link.login(msc_login_user, msc_login_pass)
    smtp_link.send_message(msg=message, from_addr=msc_from_address, to_addrs=recipient)
    smtp_link.quit()


# import smtplib
#
#
# def send_message(recipient, message):
#     smtp_obj = smtplib.SMTP('smtp.gmail.com', 587)
#     smtp_obj.starttls()
# password = 'SUraiaRpA22&'
#     smtp_link.login('live_queue@mail.ru', password)
#     smtp_obj.login('live.queue.creator@gmail.com', password)
#     smtp_obj.send_message(msg=message,
#                           from_addr='live.queue.creator@gmail.com',
#                           to_addrs=recipient)
#     smtp_obj.quit()
