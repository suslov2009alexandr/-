from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired


class Search(FlaskForm):
    search = StringField('Введите информацию о очереди для поиска',
                         validators=[DataRequired()])
    submit = SubmitField('Поиск')
