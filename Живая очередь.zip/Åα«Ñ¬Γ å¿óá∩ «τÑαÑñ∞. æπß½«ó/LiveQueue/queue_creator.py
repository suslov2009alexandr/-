from flask_wtf import FlaskForm
from wtforms import TimeField, IntegerField, TextAreaField, StringField, SubmitField, SelectMultipleField
from wtforms.validators import DataRequired
import datetime


class NullableTimeField(TimeField):
    """Native WTForms DateField throws error for empty dates.
    Let's fix this so that we could have DateField nullable."""
    def process_formdata(self, valuelist):
        if valuelist:
            date_str = ' '.join(valuelist).strip()
            if date_str == '':
                self.data = None
                return
            try:
                self.data = datetime.datetime.strptime(date_str, self.format).date()
            except ValueError:
                self.data = None
                raise ValueError(self.gettext('Not a valid date value'))


class QueueCreator(FlaskForm):
    address = StringField('Адрес', validators=[DataRequired()])
    where = StringField('Куда', validators=[DataRequired()])
    purpose = StringField('Зачем', validators=[DataRequired()])
    auxiliary_information = TextAreaField('Вспомогательная информация')
    queuing_max_number = IntegerField('Максимальное количество людей,'
                                      'стоящих в очереди', validators=[DataRequired()])
    start_time = TimeField('Время начала', validators=[DataRequired()])
    end_time = NullableTimeField('Время завершения')
    days = SelectMultipleField('Дни недели '
                               '(поле должно быть пустым, если указаны даты; выбирайте, нажав Ctrl)',
                               choices=[('ПН', 'ПН'), ('ВТ', 'ВТ'), ('СР', 'СР'),
                                        ('ЧТ', 'ЧТ'), ('ПТ', 'ПТ'), ('СБ', 'СБ'),
                                        ('ВС', 'ВС')])
    dates = StringField('Даты (вписать через пробел в формате дд.мм.гггг, '
                        'поле должно быть пустым, если указаны дни недели)')
    submit = SubmitField('Создать очередь')