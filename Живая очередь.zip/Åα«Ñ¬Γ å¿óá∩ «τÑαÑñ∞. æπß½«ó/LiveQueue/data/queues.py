import sqlalchemy
from .db_session import SqlAlchemyBase
from sqlalchemy.types import JSON
from sqlalchemy.ext.mutable import MutableDict


class Queue(SqlAlchemyBase):
    __tablename__ = 'queues'

    id = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    address = sqlalchemy.Column(sqlalchemy.String)
    where = sqlalchemy.Column(sqlalchemy.String)
    purpose = sqlalchemy.Column(sqlalchemy.String)
    auxiliary_information = sqlalchemy.Column(sqlalchemy.String,
                                              nullable=True)
    queuing = sqlalchemy.Column(MutableDict().as_mutable(JSON), default=dict())
    queuing_max_number = sqlalchemy.Column(sqlalchemy.Integer)
    start_time = sqlalchemy.Column(sqlalchemy.Time)
    end_time = sqlalchemy.Column(sqlalchemy.Time,
                                 nullable=True)
    days = sqlalchemy.Column(sqlalchemy.String,
                             nullable=True)
    dates = sqlalchemy.Column(sqlalchemy.String,
                              nullable=True)
    last_change_date = sqlalchemy.Column(sqlalchemy.Date)
    in_queue = sqlalchemy.Column(sqlalchemy.Integer, default=0)
    out_queue = sqlalchemy.Column(sqlalchemy.String, default='')
    pre_num = sqlalchemy.Column(sqlalchemy.Integer, default=0)
