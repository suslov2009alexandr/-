from data import db_session
from datetime import date, timedelta
from data.queues import Queue


def clean():
    session = db_session.create_session()
    session.query(Queue).filter(date.today() -
                                Queue.last_change_date > timedelta(days=28)).delete(synchronize_session='fetch')
    session.commit()

