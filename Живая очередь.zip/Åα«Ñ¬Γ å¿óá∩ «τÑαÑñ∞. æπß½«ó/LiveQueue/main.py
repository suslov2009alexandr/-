from flask import Flask, request, render_template, redirect
from data import db_session
from data.queues import Queue
from queue_creator import QueueCreator
from get_in_queue import GetInQueue
from search import Search
from mail import send_message
from terminator import clean
from datetime import date
from random import choice
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText


app = Flask(__name__)
app.config['SECRET_KEY'] = 'weqervfsgFbjmjrygwrth112t56778558QWTTYGq'


@app.route('/', methods=['GET', 'POST'])
def queues():
    clean()
    form = Search()
    session = db_session.create_session()
    if form.validate_on_submit():
        key_word = form.search.data
        if key_word.isdigit():
            searched_queues = session.query(Queue).filter(Queue.id == int(key_word))
        else:
            key_word = key_word.split(' ')
            all_queues = session.query(Queue).all()
            searched_queues = []
            for q in all_queues:
                count = sum([sum([1 for w in key_word if w in p]) for p in (str(q.id), q.address, q.where, q.purpose)])
                if count > 0:
                    searched_queues.append((q, count))
            searched_queues.sort(key=lambda x: x[1])
            searched_queues = [q[0] for q in searched_queues]
        return render_template('main.html', form=form, queues=searched_queues)
    else:
        all_queues = session.query(Queue).all()
        return render_template('main.html', form=form, queues=all_queues)


@app.route('/creator', methods=['GET', 'POST'])
def creator():
    form = QueueCreator()
    print(form.validate_on_submit())
    if form.validate_on_submit():
        if not form.days.data and not form.dates.data:
            return render_template('queue_creator.html', form=form)
        if form.days.data and form.dates.data:
            return render_template('queue_creator.html', form=form)
        if form.dates.data:
            try:
                q_dates = [tuple([int(i) for i in d.split('.')]) for d in form.dates.data.strip().split()]
            except Exception:
                return render_template('queue_creator.html', form=form)
        session = db_session.create_session()
        queue = session.query(Queue).filter(Queue.address == form.address.data,
                                            Queue.where == form.where.data,
                                            Queue.purpose == form.purpose.data,
                                            Queue.auxiliary_information == form.auxiliary_information.data,
                                            Queue.start_time == form.start_time.data,
                                            Queue.end_time == form.end_time.data,
                                            Queue.days == ', '.join(list(form.days.data)),
                                            Queue.dates == ', '.join(list(form.dates.data))).first()
        if not queue:
            queue = Queue(address=form.address.data,
                          where=form.where.data,
                          purpose=form.purpose.data,
                          auxiliary_information=form.auxiliary_information.data,
                          start_time=form.start_time.data,
                          end_time=form.end_time.data,
                          days=', '.join(list(form.days.data)),
                          dates=', '.join(list(form.dates.data)),
                          last_change_date=date.today())
            session.add(queue)
            q = session.query(Queue).filter(Queue.address == form.address.data,
                                            Queue.where == form.where.data,
                                            Queue.purpose == form.purpose.data,
                                            Queue.auxiliary_information == form.auxiliary_information.data,
                                            Queue.start_time == form.start_time.data,
                                            Queue.end_time == form.end_time.data,
                                            Queue.days == ', '.join(list(form.days.data)),
                                            Queue.dates == ', '.join(list(form.dates.data))).first()
            session.commit()
            return f'Очередь {q.id} создана'
        else:
            return 'Данная очередь уже создана!'
    else:
        return render_template('queue_creator.html', form=form)


@app.route('/<queue_id>', methods=['GET', 'POST'])
def get_in_queue(queue_id):
    form = GetInQueue()
    session = db_session.create_session()
    queue = session.query(Queue).filter(Queue.id == queue_id).first()
    if queue is None:
        return f'''<!doctype html>
                            <html lang="ru">
                              <head>
                                <meta charset="utf-8">
                                <title>Ошибка 404</title>
                              </head>
                              <body>
                                <h1><b>Ошибка 404</b></h1>
                                <p>Страница не найдена.</p>
                              </body>
                            </html>'''
    if form.validate_on_submit():
        if queue.queuing_max_number:
            if queue.in_queue == queue.queuing_max_number:
                session.commit()
                return 'К сожалению, сейчас в очереди больше нет мест'
        number = queue.pre_num + 1
        letters = [i for i in 'qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890']
        key = ''
        for i in range(20):
            key = key + choice(letters)
        server = '127.0.0.1:8080'  # = 'live_queue.ru'
        href = f'http://{server}/{queue_id}/{number}_{key}'
        msg = MIMEMultipart()
        msg['From'] = 'live_queue@mail.ru'
        msg['To'] = form.email.data
        msg['Subject'] = 'Ссылка на Ваш номер в очереди'
        message = f'Ссылка на ваш номер в очереди {queue_id}: \n' + href
        msg.attach(MIMEText(message, 'plain'))
        recipient = form.email.data
        send_message(recipient, msg)
        queue.last_change_date = date.today()
        queue.pre_num += 1
        queue.in_queue += 1
        queue.queuing[f'{number}_{key}'] = str(number)
        session.add(queue)
        session.commit()
        return f'Вам отправлена ссылка на ваш номер в очереди {queue_id} с почты live_queue@mail.ru'
    else:
        session.commit()
        return render_template('get_in_queue.html', form=form, queue=queue, out_queue=len(queue.out_queue.split(' ')))


@app.route('/<queue_id>/<id_key>', methods=['GET', 'POST'])
def queuing(queue_id, id_key):
    session = db_session.create_session()
    queue = session.query(Queue).filter(Queue.id == queue_id).first()
    session.commit()
    print(queue.queuing)
    if id_key not in queue.queuing:
        return f'''<!doctype html>
                    <html lang="ru">
                      <head>
                        <meta charset="utf-8">
                        <title>Ошибка 404</title>
                      </head>
                      <body>
                        <h1><b>Ошибка 404</b></h1>
                        <p>Страница не найдена.</p>
                      </body>
                    </html>'''
    else:
        return render_template('queuing.html', queuing_number=queue.queuing[id_key], queue=queue,
                               past=queue.out_queue.split(' ')[:10] if len(queue.out_queue) >= 10 else
                               queue.out_queue.split(' '), id_key=id_key)


@app.route('/<queue_id>/<id_key>/move', methods=['GET', 'POST'])
def move(queue_id, id_key):
    session = db_session.create_session()
    queue = session.query(Queue).filter(Queue.id == queue_id).first()
    # print(queue.queuing)
    if id_key not in queue.queuing:
        session.commit()
        return f'''<!doctype html>
                        <html lang="ru">
                          <head>
                            <meta charset="utf-8">
                            <title>Ошибка 404</title>
                          </head>
                          <body>
                            <h1><b>Ошибка 404</b></h1>
                            <p>Страница не найдена.</p>
                          </body>
                        </html>'''
    else:
        if request.method == 'GET':
            session.commit()
            return f'''<!doctype html>
                                <html lang="ru">
                                  <head>
                                    <meta charset="utf-8">
                                    <title>Переместится на несколько позиций назад</title>
                                  </head>
                                  <body>
                                    <div>
                                        <p>Примерное количество позиций:</p>
                                        <form method="post">
                                            <input type="number" id="positions" name="positions">
                                            <button type="submit" class="btn btn-primary">Переместится</button>
                                        </form>
                                    </div>
                                  </body>
                                </html>'''
        elif request.method == 'POST':
            if not request.form.get('positions'):
                return f'''<!doctype html>
                                                <html lang="ru">
                                                  <head>
                                                    <meta charset="utf-8">
                                                    <title>Переместится на несколько позиций назад</title>
                                                  </head>
                                                  <body>
                                                    <div>
                                                        <p>Примерное количество позиций:</p>
                                                        <form method="post">
                                                            <input type="number" id="positions">
                                                            <button type="submit" class="btn btn-primary">Переместится</button>
                                                        </form>
                                                    </div>
                                                  </body>
                                                </html>'''
            print(0)
            pos = str(int(queue.queuing[id_key].split('/')[0]) + int(request.form['positions']))
            index = sum([1 for key in queue.queuing if queue.queuing[key].split('/')[0] == pos])
            if index == 0:
                index = 2
            else:
                index += 1
            queue.queuing[id_key] = f'{pos}/{index}'
            queue.last_change_date = date.today()
            session.add(queue)
            session.commit()
            return redirect(f'/{queue_id}/{id_key}')


@app.route('/<queue_id>/<id_key>/finalize', methods=['GET', 'POST'])
def finalize(queue_id, id_key):
    session = db_session.create_session()
    queue = session.query(Queue).filter(Queue.id == queue_id).first()
    session.commit()
    if id_key not in queue.queuing:
        return f'''<!doctype html>
                        <html lang="ru">
                          <head>
                            <meta charset="utf-8">
                            <title>Ошибка 404</title>
                          </head>
                          <body>
                            <h1><b>Ошибка 404</b></h1>
                            <p>Страница не найдена.</p>
                          </body>
                        </html>'''
    else:
        if request.method == 'GET':
            return f'''<!doctype html>
                                <html lang="ru">
                                  <head>
                                    <meta charset="utf-8">
                                    <title>Подтверждение реализации услуги</title>
                                  </head>
                                  <body>
                                    <div>
                                        <p>Подтвердите реализацию услуги.</p>
                                        <form method="post">
                                            <button type="submit" class="btn btn-primary">Подтвердить</button>
                                        </form>
                                    </div>
                                  </body>
                                </html>'''
        elif request.method == 'POST':
            queue.in_queue -= 1
            queue.out_queue = queue.queuing[id_key] + ' ' + queue.out_queue
            if queue.queuing_max_number:
                queue.queuing_max_number -= 1
            del queue.queuing[id_key]
            session.add(queue)
            session.commit()
            return 'Реализация услуги подтверждена'


@app.route('/<queue_id>/<id_key>/leave', methods=['GET', 'POST'])
def leave(queue_id, id_key):
    session = db_session.create_session()
    queue = session.query(Queue).filter(Queue.id == queue_id).first()
    session.commit()
    if id_key not in queue.queuing:
        return f'''<!doctype html>
                        <html lang="ru">
                          <head>
                            <meta charset="utf-8">
                            <title>Ошибка 404</title>
                          </head>
                          <body>
                            <h1><b>Ошибка 404</b></h1>
                            <p>Страница не найдена.</p>
                          </body>
                        </html>'''
    else:
        if request.method == 'GET':
            return f'''<!doctype html>
                                <html lang="ru">
                                  <head>
                                    <meta charset="utf-8">
                                    <title>Выход из очереди</title>
                                  </head>
                                  <body>
                                    <div>
                                        <p>Вы действительо хотите покинуть очередь?</p>
                                        <form method="post">
                                            <button type="submit" class="btn btn-primary">Да</button>
                                        </form>
                                    </div>
                                  </body>
                                </html>'''
        elif request.method == 'POST':
            queue.in_queue -= 1
            if queue.queuing_max_number:
                queue.queuing_max_number += 1
            del queue.queuing[id_key]
            session.add(queue)
            session.commit()
            return 'Вы вышли из очереди'


if __name__ == '__main__':
    db_session.global_init("db/queues.sqlite")
    app.run(host='127.0.0.1', port=8080)
